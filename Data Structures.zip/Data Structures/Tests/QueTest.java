package Tests;

import java.util.Random;

import org.junit.Before;
import org.junit.Test;

import Data_Structures.*;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;


public class QueTest {
    

    Que<Integer> intQue;
    Que<String> stringQue;
    Random rand = new Random();
    int universalMax;

    @Before
    public void before(){
        intQue = new Que<Integer>();
        stringQue = new Que<String>();
        universalMax = rand.nextInt(500);
        while(universalMax <= 0){
            universalMax = rand.nextInt(500);
        }
    }

    /**
     * Tests if the que's empty() method works correctly
     */
    @Test
    public void testEmptyMethod(){
        assertTrue(intQue.empty());
        assertTrue(stringQue.empty());
        assertFalse(!intQue.empty());
        assertFalse(!intQue.empty());
        assertFalse(!stringQue.empty());
        assertEquals(stringQue.empty(), intQue.empty());
    }

    @Test
    public void testgetSize(){
        assertEquals(intQue.getSize(), 0);
        assertEquals(stringQue.getSize(), 0);
        assertEquals(stringQue.getSize(), intQue.getSize());
        String tempStr = "";
        int stringQueLength = 0;
        int length = rand.nextInt(10);
        while(length <= 0){
            length = rand.nextInt(10);
        }
        for(int curIndx = 0; curIndx < universalMax; curIndx++){
            char c = makeChar();
            if(curIndx == universalMax - 1){
                tempStr = tempStr + Character.toString(c);
                length = tempStr.length();
                stringQue.push(tempStr);
                stringQueLength = stringQueLength + 1;
                length = tempStr.length();
            }
            else {
                if(tempStr.length() == length){
                    stringQue.push(tempStr);
                    tempStr = "";
                    stringQueLength = stringQueLength + 1;
                }
                else {
                    tempStr = tempStr + Character.toString(c);
                }
            }
        }
        assertTrue(stringQueLength == stringQue.getSize());
        assertTrue(stringQue.peek(stringQue.getSize() - 1).length() == length);
    }

    @Test
    public void testPush(){
        this.stringQue.push("And the wrath of the giver");
        this.stringQue.push("Oh the mouth of the river", 0);
        this.stringQue.push("With the hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        assertTrue(this.stringQue.getSize() == 4);
        assertTrue(this.stringQue.peek(0).equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(this.stringQue.peek(1).equalsIgnoreCase("And the wrath of the giver"));
        assertTrue(this.stringQue.peek(2).equalsIgnoreCase("With the hands at the center"));
        assertTrue(this.stringQue.peek(3).equalsIgnoreCase("Oh the mouth of the river"));
    }

    @Test
    public void testChange(){
        this.stringQue.push("And the wrath of the giver");
        this.stringQue.push("Oh the mouth of the river", 0);
        this.stringQue.push("With the hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        this.stringQue.change("This is the new first data");
        this.stringQue.changeAt("This is the new second data", 1);
        this.stringQue.changeAt("This is the new third data", 2);
        this.stringQue.changeAt("This is the new fourth data", 3);
        assertTrue(this.stringQue.peek(0).equalsIgnoreCase("This is the new first data"));
        assertTrue(this.stringQue.peek(1).equalsIgnoreCase("This is the new second data"));
        assertTrue(this.stringQue.peek(2).equalsIgnoreCase("This is the new third data"));
        assertTrue(this.stringQue.peek(3).equalsIgnoreCase("This is the new fourth data"));
    }

    @Test
    public void testAddQue(){
        this.stringQue.push("Oh the mouth of the river");
        Que<String> otherQue = new Que<String>();
        otherQue.push("And the wrath of the giver");
        otherQue.push("With the hands at the center");
        otherQue.push("Oh the mouth of the river");
        this.stringQue.attachQue(otherQue);
        assertTrue(this.stringQue.getSize() == 4);
    }

    @Test
    public void testRemove(){
        this.stringQue.push("And the wrath of the giver");
        this.stringQue.push("Oh the mouth of the river", 0);
        this.stringQue.push("With the hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        this.stringQue.change("This is the new first data");
        this.stringQue.changeAt("This is the new second data", 1);
        this.stringQue.changeAt("This is the new third data", 2);
        this.stringQue.changeAt("This is the new fourth data", 3);
        assertTrue(this.stringQue.peek(0).equalsIgnoreCase("This is the new first data"));
        assertTrue(this.stringQue.peek(1).equalsIgnoreCase("This is the new second data"));
        assertTrue(this.stringQue.peek(2).equalsIgnoreCase("This is the new third data"));
        assertTrue(this.stringQue.peek(3).equalsIgnoreCase("This is the new fourth data"));
        this.stringQue.remove();
        assertTrue(this.stringQue.peek(0).equalsIgnoreCase("This is the new second data"));
        this.stringQue.remove(1);
        assertTrue(this.stringQue.peek(1).equalsIgnoreCase("This is the new fourth data"));
        assertTrue(this.stringQue.getSize() == 2);
    }

    @Test
    public void testReverse(){
        int arr[] = this.fill_int_que(universalMax);
        intQue.reverse();
        for(int indx = 0; indx < arr.length; indx = indx + 1){
            assertTrue(intQue.peek(intQue.getSize() - 1 - indx) == arr[indx]);
        }
    }

    @Test
    public void testBubbleSort(){
        this.stringQue.push("Oh the");
        this.stringQue.push("mouth of the river");
        this.stringQue.push("And");
        this.stringQue.push("the wrath");
        this.stringQue.push("of");
        this.stringQue.push("the giver");
        this.stringQue.push("With");
        this.stringQue.push("the");
        this.stringQue.push("hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        // for (int indx = 0; indx < this.stringQue.getSize(); indx = indx + 1){
        //     System.out.println(this.stringQue.peek(indx));
        // }
        this.stringQue.bubble_sort_que();

        for (int indx = 0; indx < this.stringQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.stringQue.peek(indx).compareTo(this.stringQue.peek(indx + 1)) < 0);
            // this.intQue.push(indx);
        }
        for (int indx = this.stringQue.getSize() - 1; indx >= 0; indx = indx - 1){
            this.intQue.push(indx);
        }
        // this.intQue.push(10);
        this.intQue.bubble_sort_que();
        for (int indx = 0; indx < this.intQue.getSize() - 1; indx = indx + 1){
            // System.out.println(this.intQue.peek(indx));
            assertTrue(this.intQue.peek(indx).compareTo(this.intQue.peek(indx + 1)) < 0);
        }
        // System.out.println(this.intQue.peek(this.intQue.getSize() - 1));
        
    }

    @Test
    public void testInsertSort(){
        this.stringQue.push("Oh the");
        this.stringQue.push("mouth of the river");
        this.stringQue.push("And");
        this.stringQue.push("the wrath");
        this.stringQue.push("of");
        this.stringQue.push("the giver");
        this.stringQue.push("With");
        this.stringQue.push("the");
        this.stringQue.push("hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        this.stringQue.insert_sort_que();
        for(int indx = 0; indx < this.stringQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.stringQue.peek(indx).compareTo(this.stringQue.peek(indx + 1)) < 0);
        }
    }

    @Test
    public void testSelectionSort(){
        this.stringQue.push("Oh the");
        this.stringQue.push("mouth of the river");
        this.stringQue.push("And");
        this.stringQue.push("the wrath");
        this.stringQue.push("of");
        this.stringQue.push("the giver");
        this.stringQue.push("With");
        this.stringQue.push("the");
        this.stringQue.push("hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        // for (int indx = 0; indx < this.stringQue.getSize(); indx = indx + 1){
        //     System.out.println(this.stringQue.peek(indx));
        // }
        this.stringQue.bubble_sort_que();

        for (int indx = 0; indx < this.stringQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.stringQue.peek(indx).compareTo(this.stringQue.peek(indx + 1)) < 0);
            // this.intQue.push(indx);
        }
        for (int indx = this.stringQue.getSize() - 1; indx >= 0; indx = indx - 1){
            this.intQue.push(indx);
        }
        this.intQue.selection_sort_que();
        for (int indx = 0; indx < this.intQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.intQue.peek(indx).compareTo(this.intQue.peek(indx + 1)) < 0);
        }
    }

    @Test
    public void testMergeSort(){
        this.stringQue.push("Oh the");
        this.stringQue.push("mouth of the river");
        this.stringQue.push("And");
        this.stringQue.push("the wrath");
        this.stringQue.push("of");
        this.stringQue.push("the giver");
        this.stringQue.push("With");
        this.stringQue.push("the");
        this.stringQue.push("hands at the center");
        this.stringQue.push("Oh the mouth of the river");
        this.stringQue.bubble_sort_que();

        for (int indx = 0; indx < this.stringQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.stringQue.peek(indx).compareTo(this.stringQue.peek(indx + 1)) < 0);
            // this.intQue.push(indx);
        }
        for (int indx = this.stringQue.getSize() - 1; indx >= 0; indx = indx - 1){
            this.intQue.push(indx);
        }
        this.intQue.merge_sort_que();
        for (int indx = 0; indx < this.intQue.getSize() - 1; indx = indx + 1){
            assertTrue(this.intQue.peek(indx).compareTo(this.intQue.peek(indx + 1)) < 0);
        }
    }
    
    public int[] fill_int_que(int max){
        int vals[] = new int[max];
        for(int indx = 0; indx < max; indx = indx + 1){
            this.intQue.push(indx);
            vals[indx] = indx;
        }
        return vals;
    }

    public char makeChar(){
        char[] characters = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
            'J', 'K', 'L', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
            'U', 'V', 'W', 'X', 'Y', 'Z'
        };
        int indx = rand.nextInt(characters.length);
        if(rand.nextInt(2) == 0){
            characters[indx] = Character.toLowerCase(characters[indx]);
        }
        return characters[indx];
    }
}
