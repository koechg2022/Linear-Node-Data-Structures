package Wrapper_Objects;

public class Snode <Data> extends Node<Data>{
    
    protected Snode<Data> above;

    public Snode(){
        super();
        this.above = null;
    }

    public Snode(Data info){
        super(info);
        this.above = null;
    }

    public Snode(Data info, Snode<Data> above){
        super(info);
        this.above = above;
    }
    
    public void setAbove(Snode<Data> node){
        this.above = node;
    }

    public void setAbove(Node<Data> node){
        this.above = (Snode<Data>) node;
    }

    public Snode<Data> getAbove(){
        return this.above;
    }
}
