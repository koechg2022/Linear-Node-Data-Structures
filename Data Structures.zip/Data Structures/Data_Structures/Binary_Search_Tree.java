package Data_Structures;

import java.util.ArrayList;

import Interfaces.BSTreeInterface;
import Wrapper_Objects.BSTNode;

public class Binary_Search_Tree<DataType> implements BSTreeInterface <DataType>{


    private BSTNode<DataType> root;
    private int height;
    private int size;

    @Override
    public int get_size() {
        return this.size;
    }

    @Override
    public int get_tree_height() {
        return this.height;
    }

    @Override
    public boolean is_balanced() {
        return Math.abs(this.subtree_height(this.root.get_left_child()) - this.subtree_height(this.root.get_right_child())) <= 1;
    }

    @Override
    public void balance_tree() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void add_to_tree(DataType data) throws IllegalArgumentException {
        if (data == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        if (this.size == 0){
            this.root = new BSTNode<DataType>(data);
            this.size = 1;
            this.height = 0;
        }
        else {
            this.data_adder(this.root, data);
            this.size = this.size + 1;
            this.height = this.subtree_height(this.root);
        }
    }

    @Override
    public boolean remove_from_tree(DataType data) throws IllegalArgumentException {
        if (data == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        BSTNode<DataType> removed_node = this.remove_helper(this.root, data);
        this.height = this.subtree_height(this.root);
        boolean the_answer = removed_node.getInformation() == data;
        if (the_answer){
            this.size = this.size - 1;
        }
        return the_answer;
    }

    @Override
    public int height_in_tree(DataType data) throws IllegalArgumentException {
        if (data == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        return contains_help(this.root, data, 0);
    }

    @Override
    public boolean contains(DataType data) throws IllegalArgumentException {
        if (data == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        return this.contains_help(this.root, data, 0) !=0;
    }

    @Override 
    public void reset(){
        this.height = -1;
        this.root = new BSTNode<DataType>();
        this.size = 0;
    }

    @Override
    public ArrayList<DataType> pre_order_iterator() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ArrayList<DataType> in_order_iterator() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ArrayList<DataType> post_order_iterator() {
        // TODO Auto-generated method stub
        return null;
    }
    

    // private void tree_balancer(BSTNode<DataType> this_root){
        
    // }

    // private BSTNode<DataType> get_left_most_child(BSTNode<DataType> this_root){
    //     if (this_root.get_left_child() == null){
    //         return this_root;
    //     }
    //     else {
    //         return this.get_left_most_child(this_root.get_left_child());
    //     }
    // }

    // private BSTNode<DataType> get_right_most_child(BSTNode<DataType> this_root){
    //     if (this_root.get_right_child() == null){
    //         return this_root;
    //     }
    //     else {
    //         return this.get_right_most_child(this_root);
    //     }
    // }

    private void data_adder(BSTNode<DataType> this_root, DataType data) {
        if(this_root.getInformation().toString().compareTo(data.toString()) < 0 && this_root.get_left_child() == null){
            this_root.set_left_child(new BSTNode<DataType>(data));
            this_root.get_left_child().set_parent(this_root);
        }
        else if (this_root.getInformation().toString().compareTo(data.toString()) < 0 && this_root.get_left_child() != null){
            this.data_adder(this_root.get_left_child(), data);
        }
        else if (this_root.getInformation().toString().compareTo(data.toString()) >= 0 && this_root.get_left_child() == null){
            this_root.set_right_child(new BSTNode<DataType>(data));
            this.root.get_right_child().set_parent(this_root);
        }
        else {
            this.data_adder(this_root.get_right_child(), data);
        }
    }

    private int subtree_height(BSTNode<DataType> sub_root){
        if (sub_root == null){
            return -1;
        }
        else {
            int left_depth = this.subtree_height(sub_root.get_left_child());
            int right_depth = this.subtree_height(sub_root.get_right_child());

            if (left_depth > right_depth){
                return left_depth + 1;
            }
            else {
                return right_depth + 1;
            }
        }
    }

    private BSTNode<DataType> remove_helper(BSTNode<DataType> start, DataType to_find){
        if (start == null){
            return null;
        }
        else if (start.getInformation().toString().equals(to_find.toString())){
            
            BSTNode<DataType> the_answer = start;
            //must readjust the child and parent pointers accordingly
            if (start.get_parent() == null){
                //parent is null
                if (start.get_right_child() != null && start.get_left_child() != null){
                    BSTNode<DataType> left_to_add = start.get_left_child();
                    left_to_add.set_parent(null);
                    start = start.get_right_child();
                    start.set_parent(null);
                    this.add_to_subtree(start, left_to_add);
                }
                else if (start.get_right_child() != null && start.get_left_child() == null){
                    start = start.get_right_child();
                    start.set_parent(null);
                }
                else if (start.get_right_child() == null && start.get_left_child() != null){
                    start = start.get_left_child();
                    start.set_parent(null);
                }
            }
            else {
                if (start.get_right_child() != null && start.get_left_child() != null){
                    BSTNode<DataType> left_to_add = start.get_left_child();
                    left_to_add.set_parent(null);
                    start = start.get_right_child();
                    start.set_parent(start.get_parent().get_parent());
                    this.add_to_subtree(start, left_to_add);
                }
                else if (start.get_right_child() != null && start.get_left_child() == null){
                    start = start.get_right_child();
                    start.set_parent(start.get_parent().get_parent());
                }
                else if (start.get_right_child() == null && start.get_left_child() != null){
                    start = start.get_left_child();
                    start.set_parent(start.get_parent().get_parent());
                }
            }
            return the_answer;
        }
        else if (start.getInformation().toString().compareTo(to_find.toString()) < 0){
            return this.remove_helper(start.get_right_child(), to_find);
        }
        else {
            return this.remove_helper(start.get_left_child(), to_find);
        }
    }

    private void add_to_subtree(BSTNode<DataType> sub_root, BSTNode<DataType> new_node){
        int compare = sub_root.getInformation().toString().compareTo(new_node.getInformation().toString());
        if (compare < 0 && sub_root.get_right_child() == null){
            sub_root.set_right_child(new_node);
        }
        else if (compare < 0 && sub_root.get_right_child() != null){
            this.add_to_subtree(sub_root.get_right_child(), new_node);
        }
        else if (compare >= 0 && sub_root.get_right_child() == null){
            sub_root.set_left_child(new_node);
        }
        else if (compare >= 0 && sub_root.get_left_child() != null){
            this.add_to_subtree(sub_root.get_left_child(), new_node);
        }
    }

    private int contains_help(BSTNode<DataType> start, DataType to_find, int height){
        
        if (start == null){
            return -1;
        }

        else if (start.getInformation().toString().equals(to_find.toString())){
            return height;
        }
        else if(start.getInformation().toString().compareTo(to_find.toString()) < 0){
            return this.contains_help(start.get_right_child(), to_find, height + 1);
        }
        // else if(start.getInformation().toString().compareTo(to_find.toString()) >= 0){
        //     return this.contains_help(start.get_left_child(), to_find, height + 1);
        // }
        else {
            return this.contains_help(start.get_left_child(), to_find, height + 1);
        }
    }
    
}
