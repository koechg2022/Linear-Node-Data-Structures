package Data_Structures;

import Interfaces.*;
import Wrapper_Objects.*;

public class Stack<Data> implements StackInterface <Data>{

    private Snode<Data> top;
    private Snode<Data> bottom;
    private int size;

    public Stack(){
        this.top = null;
        this.bottom = null;
        this.size = 0;
    }

    public Stack(Data info){
        this.top = new Snode<Data>(info);
        this.bottom = this.top;
        this.size = 1;
    }

    //Tested and passed
    @Override
    public boolean empty() {
        return this.size == 0;
    }

    //Tested and passed
    @Override
    public int getSize() {
        return this.size;
    }

    //Tested and passed
    @Override
    public void push(Data newData) throws IllegalArgumentException{
        if(newData == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        Snode<Data> newNode = new Snode<Data>(newData);
        newNode.setIndex(this.size);
        if(this.size == 0){
            this.top = newNode;
            this.bottom = this.top;
        }
        else if(this.size == 1){
            this.top.setAbove(newNode);
            newNode.setNext(this.top);
            this.top = this.top.getAbove();
            this.bottom = (Snode<Data>) this.top.getNext();
            ((Snode<Data>) this.top.getNext()).setAbove(this.top);
        }
        else {
            this.top.setAbove(newNode);
            newNode.setNext(this.top);
            newNode.setIndex(this.top.getIndex() + 1);
            this.top = this.top.getAbove();
        }
        this.size = this.size + 1;
    }

    //Tested and passed
    @Override
    public void push(Data newData, int index) throws IllegalArgumentException, IndexOutOfBoundsException{
        if(newData == null){
            throw new IllegalArgumentException("The data passed in is null");
        }
        if((index < 0) || (index > this.size)){
            throw new IndexOutOfBoundsException("The index passed in " + index + " cannot be outside the range [0, " + this.size + "].");
        }
        if(index == this.size){
            this.push(newData);
        }
        else {
            Snode<Data> newNode = new Snode<Data>(newData);
            if(index == 0){
                newNode.setAbove(this.bottom);
                this.bottom.setNext(newNode);
                this.bottom = (Snode<Data>) this.bottom.getNext();
                this.indexUpdater(this.bottom, 0, this.size);
            }
            else if(index == this.size){
                newNode.setNext(this.top);
                this.top.setAbove(newNode);
                this.top = this.top.getAbove();
                this.top.setIndex(this.top.getNext().getIndex() + 1);
            }
            else {
                if(index > this.size / 2){
                    this.nodeAdder(this.top, newNode, index);
                }
                else {
                    this.nodeAdder(this.bottom, newNode, index);
                }
            }
            this.size = this.size + 1;
        }
    }


    @Override
    public Data pull() throws NullPointerException {
        if(this.empty()){
            throw new NullPointerException("The Stack is empty");
        }
        Data theAnswer = null;
        if(this.size == 1){
            theAnswer = this.top.getInformation();
            this.reset();
        }
        else {
            theAnswer = this.top.getInformation();
            this.top = (Snode<Data>) this.top.getNext();
            this.top.setAbove(null);
            this.size = this.size - 1;
        }
        return theAnswer;
    }

    //Tested and passed
    @Override
    public Data pull(int index) throws NullPointerException, IndexOutOfBoundsException {
        if(this.size == 0){
            throw new NullPointerException("The Stack is empty");
        }
        if((index < 0) || (index >= this.size)){
            throw new IndexOutOfBoundsException("The index passed in, " + index + " must be inclusively [0, " + (this.size - 1) + "]");
        }
        Data theAnswer = null;
        if(this.size == 1){
            theAnswer = this.pull();
        }
        else if(this.size > 1){
            if(index == 0){
                theAnswer = this.bottom.getInformation();
                this.bottom = this.bottom.getAbove();
                this.bottom.setNext(null);
                this.indexUpdater(this.bottom, 0, this.size - 2);
            }
            else {
                Snode<Data> nodeAnswer = null;
                if(index > this.size / 2){
                    nodeAnswer = this.nodeRemover(this.bottom, index);
                }
                else {
                    nodeAnswer = this.nodeRemover(this.top, index);
                }
                theAnswer = nodeAnswer.getInformation();
            }
            this.size = this.size - 1;
        }
        return theAnswer;
    }

    @Override
    public Data peek() throws NullPointerException {
        if(this.size == 0){
            throw new NullPointerException("The Stack is empty");
        }
        return this.top.getInformation();
    }

    @Override
    public Data peek(int index) throws NullPointerException, IndexOutOfBoundsException {
        if(this.size == 0){
            throw new NullPointerException("The Stack is empty");
        }
        if((index < 0) || (index >= this.size)){
            throw new IndexOutOfBoundsException("The index " + index + " must be between [0, " + (this.size - 1) + "]");
        }
        Data theAnswer = null;
        if((index == this.size - 1) || (this.size == 1)){
            theAnswer = this.peek();
        }
        else {
            if(index > this.size / 2){
                theAnswer = this.dataPeeker(this.top, index);
            }
            else {
                theAnswer = this.dataPeeker(this.bottom, index);
            }
        }
        return theAnswer;
    }

    @Override
    public void reverse() throws NullPointerException {
        if(this.size == 0){
            throw new NullPointerException("This Stack is empty");
        }
        if(this.size > 1){
            Snode<Data> newBottom = new Snode<Data>();
            this.reverser(this.top, newBottom);
        }
    }

    @Override
    public void reset(){
        this.top = null;
        this.bottom = null;
        this.size = 0;
    }

    private void reverser(Snode<Data> from, Snode<Data> to){
        if((from.getInformation() == this.top.getInformation()) && (from.getIndex() == this.size - 1)){
            to.setInformation(from.getInformation());
            to.setIndex(0);
        }
        else {

        }
    }

    private Data dataPeeker(Snode<Data> curNode, int target){
        if(curNode.getIndex() == target){
            return curNode.getInformation();
        }
        else {
            if(curNode.getIndex() > target){
                return this.dataPeeker((Snode<Data>) curNode.getNext(), target);
            }
            else {
                return this.dataPeeker(curNode.getAbove(), target);
            }
        }
    }

    private Snode<Data> nodeRemover(Snode<Data> curNode, int target){
        if(curNode.getIndex() == target){
            Snode<Data> theAnswer = curNode;
            if(curNode.getNext() == null){
                this.bottom = this.bottom.getAbove();
                this.bottom.setNext(null);
                this.indexUpdater(this.bottom, 0, this.size - 2);
            }
            else if(theAnswer.getAbove() == null){
                this.top = (Snode<Data>) this.top.getNext();
                this.top.setAbove(null);
            }
            else {
                curNode = curNode.getAbove();
                curNode.setNext(curNode.getNext().getNext());
                ((Snode<Data>) curNode.getNext()).setAbove(curNode);
                this.indexUpdater((Snode<Data>) curNode.getNext(), curNode.getNext().getIndex(), this.size - 2);
            }
            return theAnswer;
        }
        else {
            if(curNode.getIndex() < target){
                return this.nodeRemover(curNode.getAbove(), target);
            }
            else{
                return this.nodeRemover((Snode<Data>) curNode.getNext(), target);
            }
        }
    }


    private void indexUpdater(Snode<Data> curNode, int curIndx, int target){
        if(curIndx == target){
            curNode.setIndex(target);
        }
        else {
            curNode.setIndex(curIndx);
            if(curIndx < target){
                this.indexUpdater(curNode.getAbove(), curIndx + 1, target);
            }
            else {
                this.indexUpdater((Snode<Data>) curNode.getNext(), curIndx - 1, target);
            }
        }
    }

    private void nodeAdder(Snode<Data> curNode, Snode<Data> newNode, int target){
        if(curNode.getIndex() == target){
            newNode.setIndex(target);
            newNode.setNext(curNode.getNext());
            ((Snode<Data>) newNode.getNext()).setAbove(newNode);
            newNode.setAbove(curNode);
            curNode.setNext(newNode);
            this.indexUpdater(curNode, target + 1, this.size);
        }
        else {
            if(curNode.getIndex() > target){
                this.nodeAdder((Snode<Data>) curNode.getNext(), newNode, target);
            }
            else {
                this.nodeAdder(curNode.getAbove(), newNode, target);
            }
        }
    }
    
}
