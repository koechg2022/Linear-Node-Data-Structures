package Wrapper_Objects;

public class BSTNode <DataType> extends Node <DataType>{
    
    private BSTNode<DataType> left_child;
    private BSTNode<DataType> parent;

    public BSTNode(DataType data){
        super(data);
        left_child = null;
    }

    public BSTNode(DataType data, int node_height){
        super(data, node_height);
        left_child = null;
    }

    public BSTNode(){
        super();
        this.left_child = null;
        this.parent = null;
    }

    // public DataType get_data(){
    //     return super.getInformation();
    // }

    // public void set_data(DataType data){
    //     this.setInformation(data);
    // }

    public void set_left_child(BSTNode<DataType> left_child){
        this.left_child = left_child;
    }

    public BSTNode<DataType> get_left_child(){
        return this.left_child;
    }

    public void set_node_height(int height){
        super.index = height;
    }

    public int get_node_height(){
        return this.getIndex();
    }

    public void set_right_child(BSTNode<DataType> right_child){
        this.setNext(right_child);
    }

    public BSTNode<DataType> get_right_child(){
        return (BSTNode<DataType>) this.getNext();
    }

    public void set_parent(BSTNode<DataType> parent){
        this.parent = parent;
    }

    public BSTNode<DataType> get_parent(){
        return this.parent;
    }
}
