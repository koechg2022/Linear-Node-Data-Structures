package Interfaces;
import java.util.ArrayList;

/**
 * This is my implementation of a Binay Search Tree. It will contain the following public methods:
 * <ul>
 *  <li>get_size()</li>
 *  <li>add_to_tree(data)</li>
 *  <li>remove_from_tree(data)</li>
 *  <li>height_in_tree(data)</li>
 *  <li>contains(data)</li>
 *  <li>get_tree_height()</li>
 *  <li>is_balanced()</li>
 *  <li>balance_tree()</li>
 *  <li>get_height_of(data)</li>
 * </ul>
 */
public interface BSTreeInterface<DataType> {
    
    /**
     * 
     * @return the size of the Binary Search Tree.
     */
    public int get_size();

    /**
     * @return This method returns the height of the tree.
     */
    public int get_tree_height();

    /**
     * This method checks if the Binary Search Tree is balanced or not.
     * @return {@linkplain True} if the Binary Search Tree is balanced, {@linkplain False} otherwise.
     */
    public boolean is_balanced();

    /**
     * This method balances the Binary Search Tree.
     */
    public void balance_tree();

    /**
     * This method returns an ArrayList of all the data in the tree in a pre-order ArrayList
     * @return An ArrayList with the data in a preorder list.
     */
    public ArrayList<DataType> pre_order_iterator();


    /**
     * This method returns an ArrayList of all the data in the tree in an in-order ArrayList.
     * @return An ArrayList of all the data in an inorder list.
     */
    public ArrayList<DataType> in_order_iterator();


    /**
     * This method returns an ArrayList of all the data in the tree in a post-order ArrayList.
     * @return An ArrayList of all the data in a postorder list.
     */
    public ArrayList<DataType> post_order_iterator();


    /**
     * This method takes in some data of data type, {@linkplain DataType} and adds it to the Binary Search Tree.
     * @param data is the data to be added to the Binary Search Tree.
     * @throws IllegalArgumentException is thrown if the data passed in is {@linkplain null}
     */
    public void add_to_tree(DataType data) throws IllegalArgumentException;

    /**
     * This method removes the data passed in from the Binry Search Tree and {@linkplain True} if the data was successfully removed 
     * from the tree. Otherwise, {@linkplain False} is returned.
     * @param data The data to be removed from the Binary Search Tree.
     * @return {@linkplain True} If the data is no longer in the Binary Search Tree, {@linkplain False} otherwise.
     * @throws IllegalArgumentException If the data passed in is {@linkplain null}.
     */
    public boolean remove_from_tree(DataType data) throws IllegalArgumentException;

    /**
     * This method returns the height of the data passed into the Binary Search Tree, provided the data exists in the tree. If the data 
     * does not exist in the Binary Search Tree, a -1 is returned.
     * @param data The data whose height is to be determined within the Binary Search Tree.
     * @return -1 if the data passed into this method does not exist within the Binary Search Tree, otherwise the height of the data within the tree.
     * @throws IllegalArgumentException If the data passed in is {@linkplain null}
     */
    public int height_in_tree(DataType data) throws IllegalArgumentException;

    /**
     * This method is used to check if the Binary Search Tree contains the {@linkplain data} passed in.
     * @param data The data to check and see if it is contained within the Binary Search Tree.
     * @return {@linkplain True} if the data passed in is in the Binary Search Tree, {@linkplain False} otherwise.
     * @throws IllegalArgumentException If the data passed in is {@linkplain null}.
     */
    public boolean contains(DataType data) throws IllegalArgumentException;


    /**
     * This method resets the Binary Search Tree to be empty.
     */
    public void reset();
}
