package Tests;

import java.util.Random;

import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;

import Data_Structures.Stack;

public class StackTest {
    
    Stack<String> stringStack;
    Stack<Integer> intStack;
    Random rand = new Random();
    int universalMax;

    @Before
    public void before(){
        stringStack = new Stack<String>();
        intStack = new Stack<Integer>();
        universalMax = rand.nextInt(500);
        while(universalMax <= 0){
            universalMax = rand.nextInt(500);
        }
    }

    @Test
    public void testEmpty(){
        assertTrue(stringStack.empty());
        intStack.push(universalMax);
        assertFalse(intStack.empty());
        assertEquals(true, !intStack.empty() == stringStack.empty());
    }

    @Test
    public void testgetSize(){
        for(int curIndx = 0; curIndx < universalMax; curIndx = curIndx + 1){
            intStack.push(curIndx);
            assertTrue(intStack.getSize() == curIndx + 1);
        }
    }

    @Test
    public void testPush(){
        assertTrue(stringStack.empty());
        assertTrue(intStack.empty());
        stringStack.push("Oh the mout of the river");
        stringStack.push("With the hands at the center");
        stringStack.push("And the wrath of the giver");
        stringStack.push("Oh the mouth of the river");
        assertTrue(stringStack.getSize() == 4);
    }

    @Test
    public void testPushAtIndex(){
        assertTrue(stringStack.empty());
        assertTrue(intStack.empty());
        stringStack.push("Oh the mouth of the river");
        stringStack.push("And the wrath of the giver", 0);
        stringStack.push("With the hands at the center", 0);
        stringStack.push("Oh the mouth of the river", 0);
        assertTrue(stringStack.getSize() == 4);
        stringStack.push("Here is a temporary input", 2);
    }

    @Test
    public void testPull(){
        stringStack.push("Oh the mouth of the river");
        stringStack.push("And the wrath of the giver", 0);
        stringStack.push("With the hands at the center", 0);
        stringStack.push("Oh the mouth of the river", 0);
        stringStack.push("Here is a temporary input", 2);
        assertTrue(stringStack.getSize() == 5);
        String tempVal = stringStack.pull(4);
        assertTrue(tempVal.equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(stringStack.getSize() == 4);
        stringStack.push(tempVal);
    }

    @Test
    public void testPullAtIndex(){
        stringStack.push("Oh the mouth of the river");
        stringStack.push("And the wrath of the giver", 0);
        stringStack.push("With the hands at the center", 0);
        stringStack.push("Oh the mouth of the river", 0);
        stringStack.push("Here is a temporary input", 2);
        assertTrue(stringStack.getSize() == 5);
        String tempVal = stringStack.pull(4);
        assertTrue(tempVal.equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(stringStack.getSize() == 4);
        stringStack.push(tempVal);
        assertTrue(stringStack.getSize() == 5);
        tempVal = stringStack.pull(2);
        assertTrue(stringStack.getSize() == 4);
        tempVal = stringStack.pull(stringStack.getSize() - 1);
        assertTrue(tempVal.equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(stringStack.getSize() == 3);
        tempVal = stringStack.pull(0);
        assertTrue(tempVal.equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(stringStack.getSize() == 2);
    }

    @Test
    public void peek_and_peekAtTest(){
        stringStack.push("Oh the mouth of the river");
        stringStack.push("And the wrath of the giver", 0);
        stringStack.push("With the hands at the center", 0);
        stringStack.push("Oh the mouth of the river", 0);
        assertTrue(stringStack.peek().equalsIgnoreCase("Oh the mouth of the river"));
        assertTrue(stringStack.peek(stringStack.getSize() - 2).equalsIgnoreCase("And the wrath of the giver"));
        assertTrue(stringStack.peek(stringStack.getSize() - 3).equalsIgnoreCase("With the hands at the center"));
        assertTrue(stringStack.peek(stringStack.getSize() - 4).equalsIgnoreCase("Oh the mouth of the river"));
    }


    @Test
    public void testReverse(){
        stringStack.push("Oh the mouth of the river");
        assertTrue(stringStack.peek().equalsIgnoreCase("Oh the mouth of the river"));
        stringStack.reverse();
        stringStack.reset();
        for(int curIndx = 0; curIndx < 5; curIndx = curIndx + 1){
            intStack.push(curIndx);
        }
        intStack.reverse();
    }

}
