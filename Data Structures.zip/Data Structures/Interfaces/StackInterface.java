package Interfaces;

import Data_Structures.Stack;

public interface StackInterface <Data>{
    

    /**
     * This method returns true if and only if the {@link Stack}'s size is 0, and false if the size is not 0.
     * 
     * @return true if the {@link Stack} is empty, false otherwise
     */
    public boolean empty();

    /**
     * This method returns the size of the {@link Stack}. The number returned can never be less than 0.
     * @return the size of the {@link Stack}.
     */
    public int getSize();

    /**
     * This method adds the {@link newData} to the {@link Stack}.
     * @param newData The data to be pushed onto the top of the {@link Stack}.
     * @throws IllegalArgumentException Thrown if the {@link newData} passed in is null
     */
    public void push(Data newData) throws IllegalArgumentException;

    /**
     * This method adds the {@link newData} passed in to the specified {@link index} passed in.
     * @param newData The data to be pushed onto the {@link Stack}.
     * @param index The index where the {@link newData} should be added to.
     * @throws IllegalArgumentException if the {@link newData} passed in is null.
     * @throws IndexOutOfBoundsException if the {@link index} passed in is less than 0, or greater than {@link size} of the {@link Stack}.
     */
    public void push(Data newData, int index) throws IllegalArgumentException, IndexOutOfBoundsException;

    /**
     * This method pulls the {@link Data} at the top of the {@link Stack}, and returns it: Removing the 
     * data to from the {@link Stack} in the process.
     * @return the {@link Data} that is at the front of the {@link Stack}.
     * @throws NullPointerException This exception is thrown if the {@link Stack} is empty.
     */
    public Data pull() throws NullPointerException;

    /**
     * This method returns the {@link Data} at the {@link index} passed in.
     * @param index The index with the {@link Data} that is to be retrieved. It must be greater or equal to 0, and less than the size of the {@link Stack}.
     * @return The {@link Data} at the specified index of the {@link Stack}.
     * @throws NullPointerException Thrown if the {@link Stack} is empty.
     * @throws IndexOutOfBoundsException Thrown if the {@link index} passed in is less than 0, or equal to or greater than the size of the {@link Stack}.
     */
    public Data pull(int index) throws NullPointerException, IndexOutOfBoundsException;

    /**
     * This method returns the {@link Data} at the top of the {@link Stack}.
     * @return The {@link Data} at the top of the {@link Stack}.
     * @throws NullPointerException if the {@link Stack} is empty
     */
    public Data peek()throws NullPointerException;

    /**
     * This method returns the data in the {@link Stack} at the {@link index} passed in.
     * @param index The index of the {@link Stack} with the {@link Data} to be retrieved
     * @return
     * @throws NullPointerException
     * @throws IndexOutOfBoundsException
     */
    public Data peek(int index)throws NullPointerException, IndexOutOfBoundsException;

    /**
     * This method reverses the directionality of the {@link Stack}.
     */
    public void reverse();
    
    /**
     * This method resets the {@link Stack} so that it is empty again
     * @throws NullPointerException
     */
    public void reset() throws NullPointerException;

}
